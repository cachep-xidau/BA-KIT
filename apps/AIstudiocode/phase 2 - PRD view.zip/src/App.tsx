import React from 'react';
import {
  ArrowLeft,
  FileText,
  Edit2,
  Download,
  Trash2,
  List,
  LayoutGrid,
  TrendingUp,
  Users,
  UserCircle,
  CheckSquare,
  Paperclip,
  Minus,
  Plus,
  Maximize2,
  Sparkles,
  X,
  Lightbulb,
  SpellCheck,
  ArrowRight,
  ArrowUp
} from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col overflow-hidden selection:bg-primary selection:text-white bg-background-dark text-slate-100 font-sans">
      {/* Subtle Ambient Background Glow */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px] opacity-40"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px] opacity-30"></div>
      </div>

      {/* Header */}
      <header className="glass-panel sticky top-0 z-50 flex items-center justify-between px-6 py-3 border-b border-glass-border">
        <div className="flex items-center gap-4">
          <button className="flex items-center justify-center size-8 rounded-lg hover:bg-white/10 transition-colors text-slate-400 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="h-6 w-px bg-white/10 mx-1"></div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              <h1 className="text-sm font-semibold tracking-wide text-white">Market Research Summary.pdf</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-primary/20 text-primary border border-primary/20">PDF Artifact</span>
            </div>
            <span className="text-xs text-slate-400 pl-7">Generated 2h ago • Version 1.2</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-surface-dark/50 rounded-lg p-1 border border-white/5">
            <button className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-white/5 transition-colors text-slate-300 hover:text-white text-xs font-medium">
              <Edit2 className="w-4 h-4" />
              Edit
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-white/5 transition-colors text-slate-300 hover:text-white text-xs font-medium">
              <Download className="w-4 h-4" />
              Download
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-white/5 transition-colors text-red-400/80 hover:text-red-400 text-xs font-medium hover:bg-red-500/10">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
          <button className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-lg shadow-primary/20">
            <span>Back to Project</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden relative z-10">
        {/* Left Sidebar: Document Outline */}
        <aside className="w-72 flex-shrink-0 flex flex-col glass-panel border-r border-glass-border">
          <div className="p-4 border-b border-glass-border flex justify-between items-center">
            <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Document Outline</h2>
            <List className="w-5 h-5 text-slate-500 cursor-pointer hover:text-white transition-colors" />
          </div>
          <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {/* Active Item */}
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 border border-primary/20 text-white group">
              <LayoutGrid className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium">Executive Summary</span>
            </a>
            {/* Inactive Items */}
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors group">
              <TrendingUp className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
              <span className="text-sm font-medium">Market Trends</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors group">
              <Users className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
              <span className="text-sm font-medium">Competitor Analysis</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors group">
              <UserCircle className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
              <span className="text-sm font-medium">User Personas</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors group">
              <CheckSquare className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
              <span className="text-sm font-medium">Feature Requirements</span>
            </a>
            <div className="pt-4 pb-2 px-3">
              <div className="h-px bg-white/5 w-full"></div>
            </div>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors group">
              <Paperclip className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
              <span className="text-sm font-medium">Appendix A: Data</span>
            </a>
          </nav>
          <div className="p-4 border-t border-glass-border">
            <div className="flex items-center gap-3 px-3 py-2 bg-white/5 rounded-lg border border-white/5">
              <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
              <span className="text-xs text-slate-300">Document Synced</span>
            </div>
          </div>
        </aside>

        {/* Central Viewer Area */}
        <section className="flex-1 flex flex-col bg-[#0a060e] relative overflow-hidden">
          {/* Toolbar Overlay */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 p-1.5 rounded-full bg-surface-dark/90 backdrop-blur border border-white/10 shadow-2xl">
            <button className="size-8 rounded-full flex items-center justify-center hover:bg-white/10 text-slate-300 hover:text-white transition-colors">
              <Minus className="w-5 h-5" />
            </button>
            <span className="text-xs font-medium text-slate-300 w-12 text-center">100%</span>
            <button className="size-8 rounded-full flex items-center justify-center hover:bg-white/10 text-slate-300 hover:text-white transition-colors">
              <Plus className="w-5 h-5" />
            </button>
            <div className="w-px h-4 bg-white/20 mx-1"></div>
            <button className="size-8 rounded-full flex items-center justify-center hover:bg-white/10 text-slate-300 hover:text-white transition-colors" title="Fit to Width">
              <Maximize2 className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Document Container */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden p-8 flex justify-center bg-[radial-gradient(#1f1625_1px,transparent_1px)] [background-size:16px_16px]">
            {/* Document Page */}
            <div className="w-full max-w-[800px] bg-white text-slate-900 rounded-sm shadow-2xl min-h-[1100px] p-12 relative flex flex-col gap-6">
              {/* Page Content Simulation */}
              <div className="flex justify-between items-end border-b-2 border-slate-900 pb-4 mb-4">
                <h1 className="text-4xl font-bold tracking-tight text-slate-900">Executive Summary</h1>
                <span className="text-sm font-medium text-slate-500">Page 1 of 12</span>
              </div>
              
              <div className="space-y-4 text-slate-700 leading-relaxed">
                <p>The market for enterprise resource planning (ERP) solutions in the mid-market segment is currently undergoing significant transformation. Driven by the need for greater agility and real-time data analytics, organizations are rapidly moving away from legacy on-premise systems towards cloud-native architectures.</p>
                <p>This report analyzes key trends observed in Q3 2023, highlighting a 24% increase in demand for modular ERP components rather than monolithic suites. Our research indicates that this shift is primarily motivated by cost optimization strategies and the desire for faster implementation cycles.</p>
              </div>

              <div className="my-6 p-6 bg-slate-50 rounded-lg border border-slate-200">
                <h3 className="text-lg font-semibold mb-4 text-slate-800">Market Growth Projection (2023-2025)</h3>
                <div className="flex items-end gap-4 h-48 w-full px-4">
                  <div className="w-full bg-indigo-100 rounded-t h-[40%] relative group cursor-pointer">
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">22%</div>
                  </div>
                  <div className="w-full bg-indigo-200 rounded-t h-[55%] relative group cursor-pointer">
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">35%</div>
                  </div>
                  <div className="w-full bg-indigo-300 rounded-t h-[65%] relative group cursor-pointer">
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">42%</div>
                  </div>
                  <div className="w-full bg-indigo-500 rounded-t h-[85%] relative group cursor-pointer">
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">58%</div>
                  </div>
                </div>
                <div className="flex justify-between text-xs text-slate-500 mt-2 px-4">
                  <span>Q1 '23</span>
                  <span>Q2 '23</span>
                  <span>Q3 '23</span>
                  <span>Q4 '23 (Est)</span>
                </div>
              </div>

              <div className="space-y-4 text-slate-700 leading-relaxed">
                <h3 className="text-xl font-semibold text-slate-900 mt-4">Key Findings</h3>
                <ul className="list-disc pl-5 space-y-2 marker:text-indigo-500">
                  <li><strong>Adoption Rates:</strong> Cloud adoption has surpassed on-premise deployments for the first time in this sector.</li>
                  <li><strong>Budget Allocation:</strong> IT budgets are being reallocated from maintenance to innovation projects at a rate of 15% YoY.</li>
                  <li><strong>Vendor Landscape:</strong> Niche players are gaining market share from established giants by offering specialized vertical solutions.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Right Sidebar: AI Analysis */}
        <aside className="w-80 flex-shrink-0 flex flex-col glass-panel border-l border-glass-border">
          <div className="p-4 border-b border-glass-border flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <h2 className="text-sm font-semibold text-white">AI Analysis</h2>
            </div>
            <button className="text-slate-500 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Summary Card */}
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Key Insights</h3>
              <div className="p-3 rounded-lg bg-surface-dark border border-white/5 relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-1 h-full bg-primary"></div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  This document identifies <span className="text-white font-medium">3 major gaps</span> in the current market strategy, particularly in the mid-market segment. 
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="px-2 py-1 rounded bg-white/5 border border-white/5 text-[10px] text-slate-400">Strategy</span>
                  <span className="px-2 py-1 rounded bg-white/5 border border-white/5 text-[10px] text-slate-400">Gaps</span>
                  <span className="px-2 py-1 rounded bg-white/5 border border-white/5 text-[10px] text-slate-400">Mid-market</span>
                </div>
              </div>
            </div>

            {/* Suggestions */}
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Suggested Improvements</h3>
              
              <div className="group flex gap-3 p-3 rounded-lg hover:bg-white/5 border border-transparent hover:border-white/5 transition-all cursor-pointer">
                <div className="mt-0.5 min-w-[20px]">
                  <Lightbulb className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <p className="text-sm text-slate-200 font-medium mb-1">Add Quantitative Data</p>
                  <p className="text-xs text-slate-400 leading-relaxed">Section 2 lacks specific citations. Consider adding references from the Q3 Gartner report.</p>
                  <button className="mt-2 text-xs text-primary hover:text-primary/80 font-medium flex items-center gap-1">
                    Apply Suggestion <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              <div className="group flex gap-3 p-3 rounded-lg hover:bg-white/5 border border-transparent hover:border-white/5 transition-all cursor-pointer">
                <div className="mt-0.5 min-w-[20px]">
                  <SpellCheck className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-slate-200 font-medium mb-1">Clarity Check</p>
                  <p className="text-xs text-slate-400 leading-relaxed">The paragraph on "Legacy System Migration" is slightly convoluted. Simplify sentence structure.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Chat Input */}
          <div className="p-4 border-t border-glass-border bg-surface-dark/30">
            <div className="relative">
              <input 
                type="text" 
                className="w-full bg-surface-dark border border-white/10 rounded-lg py-2.5 pl-3 pr-10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all" 
                placeholder="Ask AI about this document..." 
              />
              <button className="absolute right-1.5 top-1.5 p-1 rounded bg-primary text-white hover:bg-primary/90 transition-colors flex items-center justify-center">
                <ArrowUp className="w-4 h-4" />
              </button>
            </div>
            <p className="text-[10px] text-slate-500 mt-2 text-center">AI generated content may be inaccurate.</p>
          </div>
        </aside>
      </main>
    </div>
  );
}
