import {
  Bell,
  BrainCircuit,
  Check,
  CheckCircle2,
  ChevronRight,
  Database,
  Edit3,
  FileText,
  FolderArchive,
  History,
  Puzzle,
  Quote,
  Rocket,
  Search,
  Share,
  Share2,
} from 'lucide-react';

export default function App() {
  return (
    <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 font-display overflow-hidden h-screen flex flex-col">
      {/* Top Header */}
      <header className="flex-none flex items-center justify-between border-b border-surface-hover bg-background-dark px-6 py-3 z-20">
        <div className="flex items-center gap-4">
          <div className="size-8 rounded-lg bg-surface-hover flex items-center justify-center text-primary">
            <FolderArchive className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-white text-lg font-bold leading-tight">
              Phase 3: Design Artifacts
            </h1>
            <p className="text-text-muted text-xs">Project Alpha • Bulk Review</p>
          </div>
        </div>
        {/* Progress Widget */}
        <div className="hidden md:flex flex-col w-64 gap-1.5">
          <div className="flex justify-between text-xs text-text-muted">
            <span>Phase Completion</span>
            <span className="text-white font-medium">75%</span>
          </div>
          <div className="h-2 w-full rounded-full bg-surface-hover">
            <div className="h-full rounded-full bg-primary" style={{ width: '75%' }}></div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted w-5 h-5" />
            <input
              className="bg-surface-hover border-none rounded-xl py-2 pl-10 pr-4 text-sm text-white focus:ring-1 focus:ring-primary w-64 placeholder-text-muted/70 outline-none"
              placeholder="Search artifacts..."
              type="text"
            />
          </div>
          <button className="size-10 rounded-xl bg-surface-hover flex items-center justify-center text-white hover:bg-[#32674d] transition-colors relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 size-2 bg-red-500 rounded-full border border-surface-hover"></span>
          </button>
          <div
            className="bg-center bg-no-repeat bg-cover rounded-full size-10 border-2 border-surface-hover"
            style={{
              backgroundImage:
                'url("https://lh3.googleusercontent.com/aida-public/AB6AXuAdsPrCxdDMqemi2IGcATSZ8nX0x8lGVn8nK69oRFQ_QoO2yE5lvvuQ2djP6CpdkOl6V1zR5TG-YPeGztoUcHukwCnqlh71jRv8UJ0y5Rcwd2udMl72RkzDIq3Ug4diq1oOZL-i1VsLbue1g3PFpgyOo9AoYhmnfXJ24Sw7u6dVQ6qsuQ0yGV2I_p_bKRMuwM4xm7U8-tkGW2TBca8DWoQolP1iaK-_aBxBd1uXPg_I3awxqu-OMKQogT20ehrhvcRQZARF5BdxWgPy")',
            }}
          ></div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar: Artifact List */}
        <aside className="w-80 lg:w-96 flex-none bg-[#162b21] border-r border-surface-hover flex flex-col">
          {/* Filter Bar */}
          <div className="p-4 border-b border-surface-hover space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
                Artifacts
              </h2>
              <span className="text-xs text-text-muted bg-surface-hover px-2 py-0.5 rounded-full">
                12 Total
              </span>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              <button className="px-3 py-1 rounded-full bg-primary/20 text-primary text-xs font-medium border border-primary/20 whitespace-nowrap">
                All
              </button>
              <button className="px-3 py-1 rounded-full bg-surface-hover text-text-muted hover:text-white text-xs font-medium border border-transparent hover:border-surface-hover whitespace-nowrap cursor-pointer">
                Needs Review
              </button>
              <button className="px-3 py-1 rounded-full bg-surface-hover text-text-muted hover:text-white text-xs font-medium border border-transparent hover:border-surface-hover whitespace-nowrap cursor-pointer">
                Approved
              </button>
            </div>
          </div>

          {/* List Items */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {/* Header for list */}
            <div className="flex items-center px-3 py-2 text-text-muted text-xs">
              <input
                className="rounded border-surface-hover bg-surface-hover text-primary focus:ring-0 focus:ring-offset-0 size-4 mr-3 cursor-pointer"
                type="checkbox"
              />
              <span>Select All</span>
            </div>

            {/* Item 1 (Active) */}
            <div className="group flex items-start gap-3 p-3 rounded-lg bg-surface-hover border border-primary/30 cursor-pointer transition-all hover:bg-surface-hover/80 relative overflow-hidden">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary"></div>
              <input
                defaultChecked
                className="mt-1 rounded border-surface-hover bg-[#162b21] text-primary focus:ring-0 focus:ring-offset-0 size-4 cursor-pointer accent-primary"
                type="checkbox"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-primary flex items-center gap-1">
                    <Puzzle className="w-4 h-4" /> US-101
                  </span>
                  <span className="size-2 rounded-full bg-primary"></span>
                </div>
                <h3 className="text-sm font-medium text-white truncate">
                  User Login Authentication
                </h3>
                <p className="text-xs text-text-muted mt-1 truncate">
                  As a user, I want to securely log in...
                </p>
              </div>
            </div>

            {/* Item 2 */}
            <div className="group flex items-start gap-3 p-3 rounded-lg hover:bg-surface-hover/50 border border-transparent cursor-pointer transition-all">
              <input
                className="mt-1 rounded border-surface-hover bg-[#162b21] text-primary focus:ring-0 focus:ring-offset-0 size-4 cursor-pointer accent-primary"
                type="checkbox"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-text-muted flex items-center gap-1">
                    <Database className="w-4 h-4" /> ERD-20
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/20">
                    Needs Review
                  </span>
                </div>
                <h3 className="text-sm font-medium text-white truncate">
                  User_Profiles Schema
                </h3>
                <p className="text-xs text-text-muted mt-1 truncate">
                  Database schema update v2.4
                </p>
              </div>
            </div>

            {/* Item 3 */}
            <div className="group flex items-start gap-3 p-3 rounded-lg hover:bg-surface-hover/50 border border-transparent cursor-pointer transition-all">
              <input
                className="mt-1 rounded border-surface-hover bg-[#162b21] text-primary focus:ring-0 focus:ring-offset-0 size-4 cursor-pointer accent-primary"
                type="checkbox"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-text-muted flex items-center gap-1">
                    <Rocket className="w-4 h-4" /> EPIC-03
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-surface-hover text-text-muted border border-white/5">
                    Pending AI
                  </span>
                </div>
                <h3 className="text-sm font-medium text-white truncate">
                  Payment Gateway Integration
                </h3>
                <p className="text-xs text-text-muted mt-1 truncate">
                  Core infrastructure for Stripe...
                </p>
              </div>
            </div>

            {/* Item 4 (Approved) */}
            <div className="group flex items-start gap-3 p-3 rounded-lg hover:bg-surface-hover/50 border border-transparent cursor-pointer transition-all opacity-70">
              <input
                className="mt-1 rounded border-surface-hover bg-[#162b21] text-primary focus:ring-0 focus:ring-offset-0 size-4 cursor-pointer accent-primary"
                type="checkbox"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-text-muted flex items-center gap-1">
                    <FileText className="w-4 h-4" /> SRS-09
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-primary/20 text-primary border border-primary/20 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Approved
                  </span>
                </div>
                <h3 className="text-sm font-medium text-white truncate">
                  Security Requirements Spec
                </h3>
                <p className="text-xs text-text-muted mt-1 truncate">
                  Updated compliance protocols...
                </p>
              </div>
            </div>
          </div>
        </aside>

        {/* Right Content: Preview Pane */}
        <section className="flex-1 flex flex-col min-w-0 bg-background-dark relative">
          {/* Breadcrumbs / Toolbar */}
          <div className="h-14 border-b border-surface-hover flex items-center justify-between px-6 bg-[#11221a]/95 backdrop-blur z-10">
            <div className="flex items-center gap-2 text-sm text-text-muted">
              <span className="hover:text-white cursor-pointer">Artifacts</span>
              <ChevronRight className="w-4 h-4" />
              <span className="text-white font-medium">
                US-101: User Login Authentication
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                className="p-2 rounded-lg text-text-muted hover:text-white hover:bg-surface-hover transition-colors cursor-pointer"
                title="View History"
              >
                <History className="w-5 h-5" />
              </button>
              <button
                className="p-2 rounded-lg text-text-muted hover:text-white hover:bg-surface-hover transition-colors cursor-pointer"
                title="Share"
              >
                <Share2 className="w-5 h-5" />
              </button>
              <div className="h-4 w-px bg-surface-hover mx-1"></div>
              <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface-hover hover:bg-[#32674d] text-white text-xs font-semibold transition-colors cursor-pointer">
                <Edit3 className="w-4 h-4" /> Edit
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex px-6 border-b border-surface-hover bg-[#11221a]">
            <button className="px-4 py-3 text-sm font-medium text-primary border-b-2 border-primary cursor-pointer">
              Preview
            </button>
            <button className="px-4 py-3 text-sm font-medium text-text-muted hover:text-white transition-colors border-b-2 border-transparent cursor-pointer">
              Raw Data
            </button>
            <button className="px-4 py-3 text-sm font-medium text-text-muted hover:text-white transition-colors border-b-2 border-transparent cursor-pointer">
              Diff View
            </button>
            <button className="px-4 py-3 text-sm font-medium text-text-muted hover:text-white transition-colors border-b-2 border-transparent cursor-pointer">
              Comments (3)
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-8 lg:px-12 bg-background-dark">
            <div className="max-w-4xl mx-auto space-y-8">
              {/* Title Block */}
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-2 py-1 rounded bg-blue-500/20 text-blue-400 text-xs font-bold border border-blue-500/20 uppercase tracking-wide">
                    User Story
                  </span>
                  <span className="px-2 py-1 rounded bg-surface-hover text-text-muted text-xs font-mono">
                    ID: US-101
                  </span>
                  <span className="px-2 py-1 rounded bg-surface-hover text-text-muted text-xs font-mono">
                    Ver: 1.2
                  </span>
                </div>
                <h1 className="text-3xl font-bold text-white mb-2">
                  User Login Authentication
                </h1>
                <p className="text-lg text-text-muted">
                  Enable secure access for registered users via email/password
                  credentials.
                </p>
              </div>

              {/* Description */}
              <div className="prose prose-invert max-w-none">
                <div className="p-6 rounded-xl bg-surface-dark border border-surface-hover">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Quote className="w-5 h-5 text-primary" />
                    Description
                  </h3>
                  <p className="text-slate-300 leading-relaxed">
                    As a <strong>registered user</strong>,
                    <br />
                    I want to <strong>log in using my email and password</strong>,
                    <br />
                    So that I can{' '}
                    <strong>access my personalized dashboard and settings</strong>.
                  </p>
                </div>
              </div>

              {/* Acceptance Criteria */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">
                  Acceptance Criteria
                </h3>
                <div className="space-y-3">
                  <div className="flex gap-4 p-4 rounded-lg bg-[#162b21] border border-surface-hover">
                    <div className="mt-0.5">
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-white text-sm font-semibold">
                        Valid Credentials
                      </h4>
                      <p className="text-sm text-text-muted mt-1">
                        Given a user enters a valid email and matching password,
                        they should be redirected to the dashboard.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 p-4 rounded-lg bg-[#162b21] border border-surface-hover">
                    <div className="mt-0.5">
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-white text-sm font-semibold">
                        Invalid Password
                      </h4>
                      <p className="text-sm text-text-muted mt-1">
                        Given a user enters a valid email but incorrect password,
                        an error message "Invalid credentials" should appear.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 p-4 rounded-lg bg-[#162b21] border border-surface-hover">
                    <div className="mt-0.5">
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-white text-sm font-semibold">
                        Rate Limiting
                      </h4>
                      <p className="text-sm text-text-muted mt-1">
                        After 5 failed attempts, the account should be locked for
                        15 minutes.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Technical Notes (Simulated Code) */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">
                  Technical Implementation Notes
                </h3>
                <div className="bg-[#0d1117] rounded-lg p-4 font-mono text-sm border border-surface-hover overflow-x-auto text-slate-300">
                  <div className="flex gap-4">
                    <div className="flex flex-col text-slate-600 select-none text-right">
                      <span>1</span>
                      <span>2</span>
                      <span>3</span>
                      <span>4</span>
                      <span>5</span>
                    </div>
                    <pre>
                      <code>
                        <span className="text-purple-400">POST</span>{' '}
                        /api/v1/auth/login
                        {'\n'}
                        {'{'}
                        {'\n'}  <span className="text-green-400">"email"</span>:
                        "user@example.com",
                        {'\n'}  <span className="text-green-400">"password"</span>:
                        "********" // hashed on client side
                        {'\n'}
                        {'}'}
                      </code>
                    </pre>
                  </div>
                </div>
              </div>
            </div>
            {/* Bottom Spacer for Floating Action Bar */}
            <div className="h-32"></div>
          </div>

          {/* Floating Bulk Actions Bar */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-3xl">
            <div className="glass-panel flex items-center justify-between p-2 pl-6 rounded-2xl bg-surface-hover/80 backdrop-blur-md border border-white/10 shadow-2xl shadow-black/50">
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center size-6 rounded bg-primary text-[#11221a] text-xs font-bold">
                  3
                </span>
                <span className="text-sm font-medium text-white">
                  Items Selected
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-transparent hover:bg-white/5 text-white text-xs font-semibold border border-transparent hover:border-white/10 transition-all cursor-pointer">
                  <BrainCircuit className="w-4 h-4" />
                  AI Refine
                </button>
                <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-transparent hover:bg-white/5 text-white text-xs font-semibold border border-transparent hover:border-white/10 transition-all cursor-pointer">
                  <Share className="w-4 h-4" />
                  Export MCP
                </button>
                <div className="h-6 w-px bg-white/10 mx-1"></div>
                <button className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-primary hover:bg-[#10c96d] text-[#11221a] text-sm font-bold shadow-lg shadow-primary/20 transition-all transform active:scale-95 cursor-pointer">
                  <CheckCircle2 className="w-5 h-5" />
                  Approve Selected
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
