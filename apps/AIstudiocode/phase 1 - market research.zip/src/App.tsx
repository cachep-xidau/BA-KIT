import {
  Activity,
  AlertTriangle,
  ArrowUp,
  Blocks,
  Bot,
  Brain,
  Check,
  ClipboardList,
  Download,
  Globe,
  Mic,
  Minus,
  MinusCircle,
  PieChart,
  Plus,
  PlusCircle,
  Square,
  X,
} from 'lucide-react';

export default function App() {
  return (
    <div className="dark bg-background-dark text-slate-100 font-display overflow-hidden h-screen relative">
      {/* Background Layer (Dimmed Dashboard) */}
      <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden filter blur-[2px] select-none z-0">
        <div className="relative flex h-full w-full flex-col bg-background-dark">
          <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-[#224249] px-10 py-3">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-4 text-white">
                <Activity className="text-primary" size={24} />
                <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">
                  BMAD Analyst Portal
                </h2>
              </div>
            </div>
            <div className="flex flex-1 justify-end gap-8">
              <div className="flex items-center gap-9">
                <span className="text-white text-sm font-medium">Dashboard</span>
                <span className="text-white text-sm font-medium">Projects</span>
              </div>
            </div>
          </header>
          <div className="flex h-full flex-col p-4 gap-4">
            <div className="flex gap-4">
              <div className="w-64 flex flex-col gap-2">
                <div className="flex items-center gap-3 px-3 py-2 text-white">
                  <PieChart size={20} /> Overview
                </div>
                <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-[#224249] text-white">
                  <ClipboardList size={20} /> Analysis
                </div>
              </div>
              <div className="flex-1 flex flex-col gap-6">
                <h1 className="text-white text-[32px] font-bold">
                  Phase 1: Analysis Dashboard
                </h1>
                <div className="flex gap-4">
                  <div className="h-32 w-1/4 rounded-xl border border-[#315f68] p-6"></div>
                  <div className="h-32 w-1/4 rounded-xl border border-[#315f68] p-6"></div>
                  <div className="h-32 w-1/4 rounded-xl border border-[#315f68] p-6"></div>
                  <div className="h-32 w-1/4 rounded-xl border border-[#315f68] p-6"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Overlay */}
      <div className="relative z-10 flex h-full w-full items-center justify-center p-6 bg-black/40 backdrop-blur-sm">
        {/* AI Modal Container */}
        <div className="glass-panel flex h-[90vh] w-full max-w-7xl flex-col rounded-2xl overflow-hidden animate-fade-in-up">
          {/* Modal Header */}
          <div className="flex items-center justify-between border-b border-[#224249] bg-surface-dark/50 px-6 py-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center size-8 rounded-lg bg-primary/20 text-primary">
                <Bot size={20} />
              </div>
              <div>
                <h3 className="text-white text-lg font-bold tracking-tight">
                  AI Market Research Assistant
                </h3>
                <p className="text-slate-400 text-xs font-normal">
                  BMAD Workflow • Session ID #9821
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white transition-colors">
                <Minus size={20} />
              </button>
              <button className="p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white transition-colors">
                <Square size={20} />
              </button>
              <button className="p-2 hover:bg-red-500/20 rounded-lg text-slate-400 hover:text-red-400 transition-colors">
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Modal Body */}
          <div className="flex flex-1 overflow-hidden">
            {/* Left Sidebar: Workflow Tracker */}
            <aside className="w-72 border-r border-[#224249] bg-surface-dark/30 flex flex-col">
              <div className="p-6">
                <h4 className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-6">
                  Workflow Progress
                </h4>
                <div className="relative flex flex-col gap-8 ml-3">
                  {/* Vertical Line */}
                  <div className="absolute left-[11px] top-3 bottom-3 w-0.5 bg-[#224249] -z-10"></div>

                  {/* Step 1: Completed */}
                  <div className="flex items-start gap-4 group cursor-pointer">
                    <div className="relative flex items-center justify-center size-6 rounded-full bg-primary/20 border border-primary text-primary shrink-0 z-10 shadow-[0_0_10px_rgba(37,209,244,0.3)]">
                      <Check size={14} strokeWidth={3} />
                    </div>
                    <div className="flex flex-col -mt-1">
                      <span className="text-primary text-sm font-bold">
                        Competitor ID
                      </span>
                      <span className="text-slate-400 text-xs mt-0.5">
                        5 Competitors Identified
                      </span>
                    </div>
                  </div>

                  {/* Step 2: Active */}
                  <div className="flex items-start gap-4 group cursor-pointer">
                    <div className="relative flex items-center justify-center size-6 rounded-full bg-primary text-background-dark shrink-0 z-10 shadow-[0_0_15px_rgba(37,209,244,0.6)] ring-4 ring-primary/10">
                      <span className="text-xs font-bold">2</span>
                    </div>
                    <div className="flex flex-col -mt-1">
                      <span className="text-white text-sm font-bold glow-text">
                        SWOT Analysis
                      </span>
                      <span className="text-primary text-xs mt-0.5 font-medium animate-pulse">
                        Processing...
                      </span>
                    </div>
                  </div>

                  {/* Step 3: Pending */}
                  <div className="flex items-start gap-4 group cursor-not-allowed opacity-50">
                    <div className="relative flex items-center justify-center size-6 rounded-full bg-[#224249] border border-slate-600 text-slate-400 shrink-0 z-10">
                      <span className="text-xs font-bold">3</span>
                    </div>
                    <div className="flex flex-col -mt-1">
                      <span className="text-slate-300 text-sm font-medium">
                        Market Trends
                      </span>
                      <span className="text-slate-500 text-xs mt-0.5">
                        Pending
                      </span>
                    </div>
                  </div>

                  {/* Step 4: Pending */}
                  <div className="flex items-start gap-4 group cursor-not-allowed opacity-50">
                    <div className="relative flex items-center justify-center size-6 rounded-full bg-[#224249] border border-slate-600 text-slate-400 shrink-0 z-10">
                      <span className="text-xs font-bold">4</span>
                    </div>
                    <div className="flex flex-col -mt-1">
                      <span className="text-slate-300 text-sm font-medium">
                        Gap Analysis
                      </span>
                      <span className="text-slate-500 text-xs mt-0.5">
                        Pending
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-auto p-6 border-t border-[#224249]">
                <div className="rounded-xl bg-[#224249]/50 p-4 border border-[#315f68]">
                  <div className="flex items-center gap-3 mb-2">
                    <Brain className="text-primary" size={18} />
                    <span className="text-white text-xs font-bold">
                      Model Confidence
                    </span>
                  </div>
                  <div className="w-full bg-[#101f22] rounded-full h-1.5 mb-1">
                    <div
                      className="bg-primary h-1.5 rounded-full"
                      style={{ width: '88%' }}
                    ></div>
                  </div>
                  <span className="text-primary text-[10px] font-mono">
                    88% Accurate
                  </span>
                </div>
              </div>
            </aside>

            {/* Center: Chat Interface */}
            <main className="flex-1 flex flex-col bg-gradient-to-br from-background-dark/50 to-surface-dark/50 relative">
              {/* Chat History */}
              <div className="flex-1 overflow-y-auto p-8 space-y-8 pb-32">
                {/* AI Message 1 (Text + Matrix) */}
                <div className="flex gap-4 max-w-4xl">
                  <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                    <Bot className="text-primary" size={20} />
                  </div>
                  <div className="flex flex-col gap-2 w-full">
                    <div className="bg-surface-dark border border-[#315f68] rounded-2xl rounded-tl-none p-4 text-slate-200 text-sm leading-relaxed shadow-lg">
                      <p>
                        Based on your request for the "FinTech Mobile Banking"
                        sector, I've scanned recent market reports and
                        identified the top 5 direct competitors. Here is the
                        generated matrix for your review.
                      </p>
                    </div>

                    {/* Rich Media: Competitor Matrix */}
                    <div className="bg-[#101f22] border border-[#224249] rounded-xl overflow-hidden shadow-xl mt-2">
                      <div className="px-4 py-3 border-b border-[#224249] bg-surface-dark/50 flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                          Competitor Matrix v1.0
                        </span>
                        <button className="text-primary hover:text-white text-xs flex items-center gap-1 transition-colors">
                          <Download size={14} /> Export CSV
                        </button>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm text-slate-400">
                          <thead className="bg-[#1c363c] text-white">
                            <tr>
                              <th className="px-4 py-3 font-medium">Company</th>
                              <th className="px-4 py-3 font-medium">
                                Market Share
                              </th>
                              <th className="px-4 py-3 font-medium">
                                YoY Growth
                              </th>
                              <th className="px-4 py-3 font-medium text-right">
                                Revenue (Est)
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#224249]">
                            <tr className="hover:bg-[#224249]/30 transition-colors">
                              <td className="px-4 py-3 font-medium text-white">
                                NeoBank Corp
                              </td>
                              <td className="px-4 py-3">22%</td>
                              <td className="px-4 py-3 text-green-400">
                                +15.4%
                              </td>
                              <td className="px-4 py-3 text-right">$1.2B</td>
                            </tr>
                            <tr className="hover:bg-[#224249]/30 transition-colors">
                              <td className="px-4 py-3 font-medium text-white">
                                FinServe Inc
                              </td>
                              <td className="px-4 py-3">18%</td>
                              <td className="px-4 py-3 text-green-400">
                                +8.2%
                              </td>
                              <td className="px-4 py-3 text-right">$950M</td>
                            </tr>
                            <tr className="hover:bg-[#224249]/30 transition-colors">
                              <td className="px-4 py-3 font-medium text-white">
                                WalletPlus
                              </td>
                              <td className="px-4 py-3">12%</td>
                              <td className="px-4 py-3 text-red-400">-2.1%</td>
                              <td className="px-4 py-3 text-right">$600M</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

                {/* AI Message 2 (Transition) */}
                <div className="flex gap-4 max-w-4xl">
                  <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                    <Bot className="text-primary" size={20} />
                  </div>
                  <div className="bg-surface-dark border border-[#315f68] rounded-2xl rounded-tl-none p-4 text-slate-200 text-sm leading-relaxed shadow-lg">
                    <p>
                      Shall we proceed to the SWOT analysis for 'NeoBank Corp'?
                      I can focus on specific areas if you wish.
                    </p>
                  </div>
                </div>

                {/* User Message */}
                <div className="flex gap-4 max-w-4xl ml-auto justify-end">
                  <div className="bg-primary/20 border border-primary/30 rounded-2xl rounded-tr-none p-4 text-white text-sm leading-relaxed shadow-lg max-w-xl">
                    <p>
                      Yes, please generate the SWOT analysis. Specifically,
                      focus on threats from emerging blockchain startups and
                      regulatory changes in the EU.
                    </p>
                  </div>
                  <div
                    className="size-10 rounded-full bg-gradient-to-br from-[#224249] to-[#101f22] flex items-center justify-center shrink-0 border border-white/10"
                    style={{
                      backgroundImage:
                        "url('https://lh3.googleusercontent.com/aida-public/AB6AXuB2fcyynF8fAb83-MGptGV-fiL_l454w7-03rHq6IEyd-pmeaLGfK_tuzRkFermCylod5h1ULtGParwKbgG2O3rmWRd_PTcpsek6fqUvr2CBVUV-LuBMlViu7fux0vXjA-786aOL2LiSx9rnnBk4Zznc_AW-Lm8Q7T0NWUuA_8SSs4U23XM91Hd0hSTBhd7K0v9RurnFmabTXRORPHSJwex0U3hquv-dbdlMJmwaL7JEImywInBM3nbquWz6AjEQTgr9QghpDI4FgRF')",
                      backgroundSize: 'cover',
                    }}
                  ></div>
                </div>

                {/* AI Message 3 (SWOT Chart) */}
                <div className="flex gap-4 max-w-4xl">
                  <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                    <Bot className="text-primary" size={20} />
                  </div>
                  <div className="flex flex-col gap-2 w-full max-w-2xl">
                    <div className="bg-surface-dark border border-[#315f68] rounded-2xl rounded-tl-none p-4 text-slate-200 text-sm leading-relaxed shadow-lg">
                      <p>
                        Understood. Here is the SWOT analysis for NeoBank Corp
                        with a focus on blockchain and EU regulations.
                      </p>
                    </div>

                    {/* Rich Media: SWOT Chart */}
                    <div className="bg-[#101f22] border border-[#224249] rounded-xl overflow-hidden shadow-xl mt-2 p-6">
                      <div className="flex justify-between items-center mb-4">
                        <h5 className="text-white font-bold">
                          SWOT Analysis: NeoBank Corp
                        </h5>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                          Focus: Blockchain & Regs
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 h-64">
                        {/* Strengths */}
                        <div className="bg-[#1c363c]/50 border border-green-500/20 rounded-lg p-3 flex flex-col">
                          <div className="flex items-center gap-2 mb-2 text-green-400 font-bold text-xs uppercase">
                            <PlusCircle size={16} /> Strengths
                          </div>
                          <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                            <li>Strong API infrastructure</li>
                            <li>High user retention (EU market)</li>
                          </ul>
                        </div>
                        {/* Weaknesses */}
                        <div className="bg-[#1c363c]/50 border border-orange-500/20 rounded-lg p-3 flex flex-col">
                          <div className="flex items-center gap-2 mb-2 text-orange-400 font-bold text-xs uppercase">
                            <MinusCircle size={16} /> Weaknesses
                          </div>
                          <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                            <li>High dependency on legacy rails</li>
                            <li>Slow crypto adoption</li>
                          </ul>
                        </div>
                        {/* Opportunities */}
                        <div className="bg-[#1c363c]/50 border border-blue-500/20 rounded-lg p-3 flex flex-col">
                          <div className="flex items-center gap-2 mb-2 text-blue-400 font-bold text-xs uppercase">
                            <ArrowUp size={16} /> Opportunities
                          </div>
                          <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                            <li>DeFi integration partnerships</li>
                            <li>New EU digital identity wallet</li>
                          </ul>
                        </div>
                        {/* Threats (Highlighted) */}
                        <div className="bg-[#1c363c] border border-red-500/40 rounded-lg p-3 flex flex-col relative overflow-hidden">
                          <div className="absolute inset-0 bg-red-500/5 pointer-events-none"></div>
                          <div className="flex items-center gap-2 mb-2 text-red-400 font-bold text-xs uppercase">
                            <AlertTriangle size={16} /> Threats
                          </div>
                          <ul className="list-disc list-inside text-xs text-white font-medium space-y-1">
                            <li>MiCA Regulation Compliance Costs</li>
                            <li>DeFi Protocols undercutting fees</li>
                            <li>CBDC rollout by ECB</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Input Area & Command Bar */}
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background-dark via-background-dark to-transparent pt-12">
                {/* Command Toggles */}
                <div className="flex gap-2 mb-3 px-1">
                  <button className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#224249] hover:bg-[#315f68] border border-transparent hover:border-primary/30 transition-all group">
                    <Blocks className="text-primary" size={18} />
                    <span className="text-xs font-medium text-slate-200 group-hover:text-white">
                      Import MCP Data (Confluence)
                    </span>
                  </button>
                  <button className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/20 border border-primary/40 transition-all">
                    <Globe className="text-primary" size={18} />
                    <span className="text-xs font-medium text-primary">
                      Browse Web: Active
                    </span>
                  </button>
                </div>

                {/* Input Field Container */}
                <div className="relative flex items-center bg-[#162a2f] border border-[#315f68] rounded-xl focus-within:ring-2 focus-within:ring-primary/50 focus-within:border-primary transition-all shadow-lg">
                  <button className="pl-4 pr-2 text-slate-400 hover:text-white">
                    <PlusCircle size={24} />
                  </button>
                  <input
                    className="w-full bg-transparent border-none text-white placeholder-slate-500 focus:ring-0 h-14 outline-none"
                    placeholder="Refine SWOT parameters or continue to Market Trends..."
                    type="text"
                    defaultValue=""
                  />
                  <div className="pr-2 flex items-center gap-2">
                    <button className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors">
                      <Mic size={20} />
                    </button>
                    <button className="bg-primary hover:bg-primary-dark text-background-dark p-2 rounded-lg transition-colors flex items-center justify-center">
                      <ArrowUp size={20} />
                    </button>
                  </div>
                </div>
                <div className="text-center mt-2">
                  <p className="text-[10px] text-slate-600">
                    AI can make mistakes. Verify critical data manually.
                  </p>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
