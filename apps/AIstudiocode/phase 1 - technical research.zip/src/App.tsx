import React from 'react';
import {
  LayoutGrid,
  FlaskConical,
  Save,
  Download,
  X,
  Check,
  Sparkles,
  Bot,
  ArrowRightLeft,
  AlertTriangle,
  User,
  Cloud,
  Sigma,
  Database,
  Maximize2,
  PlusCircle,
  Mic,
  Send,
  SlidersHorizontal,
  ChevronDown,
  ShieldCheck,
  Activity
} from 'lucide-react';

export default function App() {
  return (
    <div className="bg-background-dark text-slate-100 h-screen overflow-hidden flex flex-col relative font-display">
      {/* Background Layer */}
      <div 
        className="absolute inset-0 z-0 opacity-40 pointer-events-none" 
        style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, #2f2249 0%, #0f0f12 70%)' }}
      ></div>

      {/* Top Nav (Blurred) */}
      <header className="relative z-0 flex items-center justify-between border-b border-[#2f2249] px-10 py-3 bg-surface-dark/50 blur-[2px]">
        <div className="flex items-center gap-4 text-white">
          <LayoutGrid size={24} />
          <h2 className="text-lg font-bold">Project Alpha Dashboard</h2>
        </div>
        <div className="flex gap-2">
          <div className="h-10 w-10 rounded-full bg-[#2f2249]"></div>
          <div className="h-10 w-10 rounded-full bg-[#2f2249]"></div>
        </div>
      </header>

      {/* Main Content Area (Blurred) */}
      <main className="flex-1 flex p-6 gap-6 blur-[2px] opacity-50 pointer-events-none">
        <div className="w-64 bg-surface-dark rounded-xl"></div>
        <div className="flex-1 bg-surface-dark rounded-xl"></div>
      </main>

      {/* MODAL OVERLAY */}
      <div className="absolute inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/60 backdrop-blur-sm">
        <div className="glass-modal w-full max-w-[1400px] h-[90vh] rounded-2xl flex flex-col overflow-hidden shadow-glow">
          
          {/* Modal Header */}
          <header className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-white/5">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/20 rounded-lg text-primary">
                <FlaskConical size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold leading-tight">Technical Research: Project Alpha</h2>
                <p className="text-xs text-slate-400">Phase 1: Analysis & Architecture</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-300 hover:text-white transition-colors">
                <Save size={18} />
                Save Draft
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary-hover text-white text-sm font-bold rounded-lg transition-all shadow-lg shadow-primary/20">
                <Download size={18} />
                Export Report
              </button>
              <button className="p-2 text-slate-400 hover:text-white transition-colors ml-2">
                <X size={24} />
              </button>
            </div>
          </header>

          {/* Modal Body */}
          <div className="flex flex-1 overflow-hidden">
            
            {/* LEFT COLUMN: Stepper */}
            <aside className="w-64 flex-shrink-0 border-r border-white/10 bg-surface-dark/30 flex flex-col p-6 overflow-y-auto">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-6">BMAD Workflow</h3>
              
              <div className="relative flex flex-col gap-8 ml-3">
                {/* Vertical Line */}
                <div className="absolute left-[11px] top-3 bottom-3 w-0.5 bg-white/10 -z-10"></div>
                
                {/* Step 1: Active */}
                <div className="group flex gap-4 items-start relative">
                  <div className="relative z-10 w-6 h-6 rounded-full bg-primary flex items-center justify-center shadow-[0_0_10px_rgba(89,13,242,0.6)]">
                    <Check size={14} className="text-white" />
                  </div>
                  <div className="flex flex-col pt-0.5">
                    <span className="text-sm font-bold text-white">Discovery</span>
                    <span className="text-xs text-primary mt-1">Tech Stack Selection</span>
                  </div>
                </div>

                {/* Step 2: Active/Current */}
                <div className="group flex gap-4 items-start relative">
                  <div className="relative z-10 w-6 h-6 rounded-full bg-surface-dark border-2 border-primary flex items-center justify-center shadow-[0_0_10px_rgba(89,13,242,0.3)]">
                    <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                  </div>
                  <div className="flex flex-col pt-0.5">
                    <span className="text-sm font-bold text-white">API Mapping</span>
                    <span className="text-xs text-slate-400 mt-1">In Progress</span>
                  </div>
                </div>

                {/* Step 3: Pending */}
                <div className="group flex gap-4 items-start relative opacity-50">
                  <div className="relative z-10 w-6 h-6 rounded-full bg-surface-dark border-2 border-slate-600 flex items-center justify-center">
                    <span className="text-[10px] font-bold text-slate-400">3</span>
                  </div>
                  <div className="flex flex-col pt-0.5">
                    <span className="text-sm font-medium text-slate-300">Security</span>
                  </div>
                </div>

                {/* Step 4: Pending */}
                <div className="group flex gap-4 items-start relative opacity-50">
                  <div className="relative z-10 w-6 h-6 rounded-full bg-surface-dark border-2 border-slate-600 flex items-center justify-center">
                    <span className="text-[10px] font-bold text-slate-400">4</span>
                  </div>
                  <div className="flex flex-col pt-0.5">
                    <span className="text-sm font-medium text-slate-300">Data Architecture</span>
                  </div>
                </div>
              </div>

              <div className="mt-auto pt-6 border-t border-white/10">
                <div className="p-4 rounded-xl bg-gradient-to-br from-primary/20 to-transparent border border-primary/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles size={14} className="text-primary" />
                    <span className="text-xs font-bold text-primary">AI Status</span>
                  </div>
                  <p className="text-xs text-slate-300">Analyzing compatibility between Node.js and legacy SQL systems.</p>
                </div>
              </div>
            </aside>

            {/* CENTER COLUMN: AI Chat Interface */}
            <main className="flex-1 flex flex-col bg-transparent relative overflow-hidden">
              {/* Chat Area */}
              <div className="flex-1 overflow-y-auto p-6 scrollbar-hide flex flex-col gap-6">
                
                {/* AI Message */}
                <div className="flex gap-4 max-w-3xl">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Bot size={20} className="text-white" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <div className="glass-panel p-4 rounded-2xl rounded-tl-none">
                      <p className="text-sm leading-relaxed text-slate-200">
                        I've analyzed the initial requirements for <strong>Project Alpha</strong>. Based on the need for real-time data processing and high concurrency (10k+ users), here is a comparison between a traditional MERN stack and a Serverless AWS architecture.
                      </p>
                    </div>
                    
                    {/* Card: Tech Stack Comparison */}
                    <div className="glass-panel p-0 rounded-xl border border-white/10 overflow-hidden w-full max-w-xl">
                      <div className="bg-white/5 px-4 py-3 border-b border-white/10 flex justify-between items-center">
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <ArrowRightLeft size={18} className="text-primary" />
                          Tech Stack Comparison
                        </h4>
                        <span className="text-xs text-slate-400">Updated 2m ago</span>
                      </div>
                      <div className="p-4 grid grid-cols-2 gap-4">
                        {/* Option A */}
                        <div className="bg-surface-dark/50 p-3 rounded-lg border border-primary/30 relative">
                          <div className="absolute -top-2 -right-2 bg-primary text-white text-[10px] px-2 py-0.5 rounded-full font-bold shadow-glow">RECOMMENDED</div>
                          <h5 className="text-sm font-bold text-white mb-2">Serverless (AWS)</h5>
                          <ul className="text-xs text-slate-300 space-y-1.5">
                            <li className="flex items-center gap-2"><Check size={14} className="text-green-400" /> Auto-scaling</li>
                            <li className="flex items-center gap-2"><Check size={14} className="text-green-400" /> Pay-per-use</li>
                            <li className="flex items-center gap-2"><AlertTriangle size={14} className="text-yellow-400" /> Cold starts</li>
                          </ul>
                        </div>
                        {/* Option B */}
                        <div className="bg-surface-dark/30 p-3 rounded-lg border border-white/5">
                          <h5 className="text-sm font-bold text-slate-400 mb-2">MERN Stack</h5>
                          <ul className="text-xs text-slate-400 space-y-1.5">
                            <li className="flex items-center gap-2"><Check size={14} className="text-green-400" /> Simplified Dev</li>
                            <li className="flex items-center gap-2"><X size={14} className="text-red-400" /> Server Maintenance</li>
                            <li className="flex items-center gap-2"><X size={14} className="text-red-400" /> Fixed Costs</li>
                          </ul>
                        </div>
                      </div>
                      <div className="bg-white/5 px-4 py-2 text-center border-t border-white/10">
                        <button className="text-xs text-primary font-bold hover:text-primary-hover transition-colors">View Detailed Report</button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* User Message */}
                <div className="flex gap-4 max-w-3xl self-end flex-row-reverse">
                  <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0 border border-white/10">
                    <User size={20} className="text-slate-300" />
                  </div>
                  <div className="glass-panel p-4 rounded-2xl rounded-tr-none bg-primary/20 border-primary/30">
                    <p className="text-sm text-white">
                      That makes sense. Can you visualize the high-level architecture for the Serverless option? Specifically how we handle the WebSocket connections?
                    </p>
                  </div>
                </div>

                {/* AI Message with Diagram Placeholder */}
                <div className="flex gap-4 max-w-3xl animate-fade-in-up">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Bot size={20} className="text-white" />
                  </div>
                  <div className="flex flex-col gap-2 w-full">
                    <div className="glass-panel p-4 rounded-2xl rounded-tl-none">
                      <p className="text-sm leading-relaxed text-slate-200">
                        Certainly. For WebSockets on AWS, we'll use <strong>API Gateway (WebSocket API)</strong> connected to Lambda functions to manage connections and DynamoDB to store connection IDs. Here is a draft architecture diagram:
                      </p>
                    </div>
                    
                    {/* Diagram Placeholder */}
                    <div className="glass-panel p-4 rounded-xl border border-white/10 w-full relative group cursor-pointer hover:border-primary/50 transition-all">
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50 z-10 rounded-xl"></div>
                      <div className="h-64 w-full bg-surface-dark rounded-lg flex items-center justify-center relative overflow-hidden">
                        {/* Abstract Grid Background for Diagram */}
                        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(#4f46e5 1px, transparent 1px), linear-gradient(90deg, #4f46e5 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                        
                        {/* Diagram Nodes (Abstract) */}
                        <div className="flex items-center gap-8 relative z-0">
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-12 h-12 bg-[#2f2249] rounded-lg border border-indigo-500 flex items-center justify-center shadow-[0_0_15px_rgba(79,70,229,0.5)]">
                              <Cloud size={24} className="text-indigo-400" />
                            </div>
                            <span className="text-[10px] font-mono text-indigo-300">API Gateway</span>
                          </div>
                          <div className="h-0.5 w-12 bg-indigo-500/50"></div>
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-12 h-12 bg-[#2f2249] rounded-lg border border-purple-500 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.5)]">
                              <Sigma size={24} className="text-purple-400" />
                            </div>
                            <span className="text-[10px] font-mono text-purple-300">Lambda</span>
                          </div>
                          <div className="h-0.5 w-12 bg-indigo-500/50"></div>
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-12 h-12 bg-[#2f2249] rounded-lg border border-blue-500 flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.5)]">
                              <Database size={24} className="text-blue-400" />
                            </div>
                            <span className="text-[10px] font-mono text-blue-300">DynamoDB</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="absolute bottom-4 right-4 z-20">
                        <button className="flex items-center gap-2 px-3 py-1.5 bg-black/60 hover:bg-black/80 backdrop-blur-md text-white text-xs font-bold rounded-lg border border-white/10 transition-colors">
                          <Maximize2 size={14} />
                          Expand
                        </button>
                      </div>
                      <div className="absolute top-4 left-4 z-20 flex gap-2">
                        <span className="px-2 py-1 bg-primary/20 text-primary text-[10px] font-bold uppercase rounded border border-primary/20">Draft v0.1</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chat Input */}
              <div className="p-6 pt-2">
                <div className="relative flex items-center bg-surface-dark border border-white/10 rounded-xl shadow-lg focus-within:border-primary/50 focus-within:ring-1 focus-within:ring-primary/50 transition-all">
                  <button className="p-3 text-slate-400 hover:text-white transition-colors">
                    <PlusCircle size={20} />
                  </button>
                  <input 
                    className="flex-1 bg-transparent border-none text-sm text-white placeholder-slate-500 focus:ring-0 p-3 outline-none" 
                    placeholder="Ask follow up questions about security or cost..." 
                    type="text"
                  />
                  <div className="flex items-center pr-2 gap-1">
                    <button className="p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-white/5" title="Voice Input">
                      <Mic size={20} />
                    </button>
                    <button className="p-2 bg-primary hover:bg-primary-hover text-white rounded-lg transition-colors shadow-lg shadow-primary/20 m-1">
                      <Send size={20} />
                    </button>
                  </div>
                </div>
              </div>
            </main>

            {/* RIGHT COLUMN: System Specs Sidebar */}
            <aside className="w-80 flex-shrink-0 border-l border-white/10 bg-surface-dark/40 flex flex-col overflow-y-auto">
              <div className="p-5 border-b border-white/10">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <SlidersHorizontal size={18} className="text-primary" />
                  System Constraints
                </h3>
              </div>
              
              <div className="p-5 flex flex-col gap-6">
                {/* Cloud Provider */}
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wide">Cloud Provider</label>
                  <div className="relative">
                    <select className="w-full bg-surface-dark border border-white/10 rounded-lg text-sm text-white py-2.5 px-3 focus:border-primary focus:ring-1 focus:ring-primary appearance-none cursor-pointer outline-none">
                      <option>AWS (Amazon Web Services)</option>
                      <option>Google Cloud Platform</option>
                      <option>Microsoft Azure</option>
                    </select>
                    <div className="absolute right-3 top-2.5 pointer-events-none text-slate-400">
                      <ChevronDown size={18} />
                    </div>
                  </div>
                </div>

                {/* Est. Users Slider */}
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-end">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wide">Est. Concurrent Users</label>
                    <span className="text-xs font-mono text-primary bg-primary/10 px-1.5 py-0.5 rounded">10,000</span>
                  </div>
                  <input 
                    className="w-full h-1.5 bg-surface-dark rounded-lg appearance-none cursor-pointer accent-primary" 
                    max="50000" 
                    min="1000" 
                    type="range" 
                    defaultValue="10000"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>1k</span>
                    <span>50k</span>
                  </div>
                </div>

                {/* Latency Requirement */}
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-end">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wide">Max Latency (ms)</label>
                    <span className="text-xs font-mono text-primary bg-primary/10 px-1.5 py-0.5 rounded">&lt; 200ms</span>
                  </div>
                  <input 
                    className="w-full h-1.5 bg-surface-dark rounded-lg appearance-none cursor-pointer accent-primary" 
                    max="1000" 
                    min="50" 
                    type="range" 
                    defaultValue="200"
                  />
                </div>

                {/* Compliance Toggles */}
                <div className="flex flex-col gap-3">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wide">Compliance</label>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-surface-dark border border-white/5">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={18} className="text-slate-400" />
                      <span className="text-sm text-white">GDPR</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" defaultChecked />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-surface-dark border border-white/5">
                    <div className="flex items-center gap-2">
                      <Activity size={18} className="text-slate-400" />
                      <span className="text-sm text-white">HIPAA</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                </div>

                {/* Budget Input */}
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wide">Monthly Budget ($)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400">$</span>
                    <input 
                      className="w-full bg-surface-dark border border-white/10 rounded-lg text-sm text-white py-2.5 pl-7 pr-3 focus:border-primary focus:ring-1 focus:ring-primary outline-none" 
                      type="number" 
                      defaultValue="2500"
                    />
                  </div>
                </div>

                <div className="mt-auto pt-4">
                  <button className="w-full py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                    Reset Filters
                  </button>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  );
}
