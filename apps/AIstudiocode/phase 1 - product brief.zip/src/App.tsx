import { 
  FileText, Download, Sparkles, ArrowRight, Target, Users, Star, LineChart, 
  Brain, GripVertical, Database, Filter, Search, Move, Link as LinkIcon, Lightbulb, Edit2 
} from 'lucide-react';

export default function App() {
  return (
    <div className="dark bg-background-dark text-slate-100 h-screen flex flex-col overflow-hidden font-sans">
      {/* Header */}
      <header className="h-16 border-b border-border-dark flex items-center justify-between px-6 bg-surface-darker z-20 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center text-primary">
            <FileText size={20} />
          </div>
          <div>
            <h1 className="text-base font-semibold text-white leading-tight">Project Alpha: Product Brief</h1>
            <p className="text-xs text-slate-400">Phase 1 Research • Last edited 2 mins ago</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800 rounded-lg transition-colors">
            <Download size={18} />
            Export to PDF
          </button>
          <div className="h-6 w-px bg-border-dark mx-1"></div>
          <button className="flex items-center gap-2 px-4 py-2 bg-surface-dark hover:bg-slate-700 border border-border-dark rounded-lg text-white text-sm font-medium transition-all shadow-sm">
            <Sparkles size={16} className="text-primary" />
            Generate with AI
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-blue-600 text-white text-sm font-bold rounded-lg shadow-lg shadow-primary/20 transition-colors">
            Proceed to Phase 2 (PRD)
            <ArrowRight size={18} />
          </button>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Navigation Rail */}
        <aside className="w-64 glass-panel border-r border-border-dark flex-col shrink-0 z-10 hidden md:flex">
          <div className="p-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Brief Sections</h3>
            <nav className="space-y-1">
              <a href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg bg-primary/10 text-primary font-medium text-sm border-l-2 border-primary">
                <FileText size={18} />
                Executive Summary
              </a>
              <a href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-300 text-sm transition-colors border-l-2 border-transparent">
                <Target size={18} />
                Project Goals
              </a>
              <a href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-300 text-sm transition-colors border-l-2 border-transparent">
                <Users size={18} />
                Target Audience
              </a>
              <a href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-300 text-sm transition-colors border-l-2 border-transparent">
                <Star size={18} />
                Key Features (BMAD)
              </a>
              <a href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-300 text-sm transition-colors border-l-2 border-transparent">
                <LineChart size={18} />
                Success Metrics
              </a>
            </nav>
          </div>
          <div className="mt-auto p-4 border-t border-border-dark">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-slate-700 overflow-hidden">
                  <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuCpFylNGQCgTbX8dOoldyxKlB903WJJkPXe3ZYWGKVLJMOeUrYteJj1ZWzC_FQrqkyOEHtKqx5AGCczt28PVptkZECriDsAwXJ_bU1sQ-tkO2NgwlTW1QXxdKl93Ml3bE0OTB_xtMP78ajedCwqlMJQgAfkW5HK3sKtle4_qduLBDUnTZHZBRdhO7mnTMWpqYTdwvpC3I93UpQldjf94jck7_9PBxQbHXyaV8SOwLNChjTXaxdoCfyiJ1wLknUb6lvcca8Stsivec_w" alt="User Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-surface-darker"></div>
              </div>
              <div>
                <p className="text-sm font-medium text-white">Alex Chen</p>
                <p className="text-xs text-slate-400">Lead Analyst</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Editor Area */}
        <main className="flex-1 overflow-y-auto bg-[#0b1221] relative flex justify-center">
          <div className="max-w-[800px] w-full py-10 px-8 pb-32">
            {/* Document Header */}
            <div className="mb-10 text-center">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-4">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                Phase 1 Research Complete
              </div>
              <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Product Brief</h1>
              <p className="text-slate-400 text-lg">Define the core vision and requirements derived from BMAD research.</p>
            </div>

            {/* Editor Sections */}
            <div className="flex flex-col gap-8">
              {/* Section 1: Exec Summary */}
              <div className="group bg-surface-darker rounded-xl border border-border-dark p-6 shadow-sm transition-all hover:shadow-md hover:border-primary/30 relative">
                <div className="absolute -left-3 top-6 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-1.5 h-8 bg-primary rounded-full"></div>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-slate-100 flex items-center gap-2">
                    1. Executive Summary
                  </h2>
                  <button className="text-primary hover:text-blue-400 text-sm font-medium flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                    <Sparkles size={14} />
                    Auto-fill
                  </button>
                </div>
                <div className="min-h-[120px] text-slate-300 leading-relaxed outline-none" contentEditable suppressContentEditableWarning>
                  <p className="mb-2">Project Alpha aims to revolutionize the way BSA teams collaborate by introducing a centralized...</p>
                  <p className="text-slate-400 italic">Start typing or drag research findings here...</p>
                </div>
              </div>

              {/* Section 2: Goals */}
              <div className="group bg-surface-darker rounded-xl border border-border-dark p-6 shadow-sm transition-all hover:shadow-md hover:border-primary/30 relative">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-slate-100">
                    2. Project Goals
                  </h2>
                </div>
                <div className="bg-slate-900/50 rounded-lg p-4 border border-dashed border-slate-700 flex flex-col items-center justify-center gap-3 text-center min-h-[160px]">
                  <div className="p-3 bg-primary/10 rounded-full text-primary">
                    <Brain size={24} />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-white">Need a starting point?</h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">I can draft goals based on your "Brainstorming Session #4" notes.</p>
                  </div>
                  <button className="px-4 py-2 bg-slate-800 border border-border-dark rounded-md text-sm font-medium hover:bg-slate-700 transition-colors shadow-sm text-primary">
                    Draft Goals with AI
                  </button>
                </div>
              </div>

              {/* Section 3: Target Audience */}
              <div className="group bg-surface-darker rounded-xl border border-border-dark p-6 shadow-sm transition-all hover:shadow-md hover:border-primary/30 relative">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-slate-100">
                    3. Target Audience
                  </h2>
                </div>
                <div className="min-h-[100px] text-slate-300 leading-relaxed outline-none" contentEditable suppressContentEditableWarning>
                  <ul className="list-disc pl-5 space-y-2">
                    <li><strong>Primary User:</strong> Senior Business Systems Analyst (BSA) looking for efficiency.</li>
                    <li><strong>Secondary User:</strong> Product Managers overseeing roadmap alignment.</li>
                  </ul>
                </div>
              </div>

              {/* Section 4: Key Features */}
              <div className="group bg-surface-darker rounded-xl border border-border-dark p-6 shadow-sm transition-all hover:shadow-md hover:border-primary/30 relative ring-2 ring-primary/20">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-slate-100">
                    4. Key Features (BMAD)
                  </h2>
                  <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2 py-1 rounded">Linked to Market Research</span>
                </div>
                <div className="min-h-[120px] text-slate-300 leading-relaxed outline-none">
                  <div className="flex flex-col gap-3">
                    <div className="p-3 rounded bg-blue-900/20 border border-blue-800/50 flex gap-3">
                      <GripVertical size={16} className="text-primary mt-0.5 cursor-grab" />
                      <div>
                        <p className="font-medium text-blue-100 text-sm">Automated Document Parsing</p>
                        <p className="text-xs text-blue-300/70 mt-1">Source: Competitor Analysis - "Tool X lacks this"</p>
                      </div>
                    </div>
                    <div className="p-3 rounded bg-blue-900/20 border border-blue-800/50 flex gap-3 opacity-50">
                      <GripVertical size={16} className="text-primary mt-0.5 cursor-grab" />
                      <div>
                        <p className="font-medium text-blue-100 text-sm">Real-time Collaboration</p>
                        <p className="text-xs text-blue-300/70 mt-1">Source: User Interviews - "Top pain point"</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Floating FAB for Mobile */}
          <button className="md:hidden fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-xl flex items-center justify-center z-50">
            <Edit2 size={24} />
          </button>
        </main>

        {/* Right Sidebar: BMAD Reference */}
        <aside className="w-80 glass-panel border-l border-border-dark flex-col shrink-0 z-10 hidden xl:flex">
          <div className="p-4 border-b border-border-dark bg-surface-darker/50 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Database size={18} className="text-primary" />
                BMAD Reference
              </h3>
              <button className="text-slate-400 hover:text-white transition-colors">
                <Filter size={18} />
              </button>
            </div>
            {/* Search */}
            <div className="relative">
              <Search size={16} className="absolute left-2.5 top-2.5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search findings..." 
                className="w-full bg-slate-800 border-none rounded-lg py-2 pl-9 pr-3 text-sm text-slate-200 placeholder:text-slate-500 focus:ring-1 focus:ring-primary outline-none"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Section: Brainstorming */}
            <div>
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 px-1">Brainstorming Ideas</h4>
              <div className="space-y-3">
                <div className="group bg-surface-dark border border-border-dark rounded-lg p-3 cursor-grab active:cursor-grabbing shadow-sm hover:shadow-md hover:border-primary/50 transition-all select-none" draggable>
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] font-bold text-orange-500 bg-orange-500/10 px-1.5 py-0.5 rounded">Pain Point</span>
                    <Move size={14} className="text-slate-400 group-hover:text-primary" />
                  </div>
                  <p className="text-sm text-slate-300 font-medium leading-snug">Manual data entry is prone to 20% error rate.</p>
                </div>
                <div className="group bg-surface-dark border border-border-dark rounded-lg p-3 cursor-grab active:cursor-grabbing shadow-sm hover:shadow-md hover:border-primary/50 transition-all select-none" draggable>
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] font-bold text-purple-500 bg-purple-500/10 px-1.5 py-0.5 rounded">Idea</span>
                    <Move size={14} className="text-slate-400 group-hover:text-primary" />
                  </div>
                  <p className="text-sm text-slate-300 font-medium leading-snug">"One-click" approval workflow for stakeholders.</p>
                </div>
              </div>
            </div>

            {/* Section: Market Research */}
            <div>
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 px-1">Market Research</h4>
              <div className="space-y-3">
                <div className="group bg-surface-dark border border-border-dark rounded-lg p-3 cursor-grab active:cursor-grabbing shadow-sm hover:shadow-md hover:border-primary/50 transition-all select-none" draggable>
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] font-bold text-blue-500 bg-blue-500/10 px-1.5 py-0.5 rounded">Competitor</span>
                    <Move size={14} className="text-slate-400 group-hover:text-primary" />
                  </div>
                  <p className="text-sm text-slate-300 font-medium leading-snug">Competitor A lacks mobile responsiveness.</p>
                  <div className="mt-2 text-[10px] text-slate-500 flex items-center gap-1">
                    <LinkIcon size={10} /> Source: G2 Reviews
                  </div>
                </div>
                <div className="group bg-surface-dark border border-border-dark rounded-lg p-3 cursor-grab active:cursor-grabbing shadow-sm hover:shadow-md hover:border-primary/50 transition-all select-none" draggable>
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] font-bold text-green-500 bg-green-500/10 px-1.5 py-0.5 rounded">Trend</span>
                    <Move size={14} className="text-slate-400 group-hover:text-primary" />
                  </div>
                  <p className="text-sm text-slate-300 font-medium leading-snug">Rise of AI-assisted documentation in Enterprise tools.</p>
                </div>
              </div>
            </div>

            {/* AI Insight Widget */}
            <div className="bg-gradient-to-br from-indigo-900/40 to-purple-900/40 rounded-xl p-4 border border-indigo-500/20">
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb size={18} className="text-yellow-400" />
                <h4 className="text-sm font-bold text-white">AI Insight</h4>
              </div>
              <p className="text-xs text-indigo-100 leading-relaxed mb-3">
                Based on your market research, 60% of competitors are focusing on integration capabilities this quarter. Consider adding an "Integrations" section.
              </p>
              <button className="text-xs font-semibold text-white bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded transition-colors w-full">
                Add Section
              </button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
