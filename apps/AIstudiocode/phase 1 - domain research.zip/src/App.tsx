import {
  Brain,
  Minus,
  Maximize2,
  X,
  Check,
  Network,
  Sparkles,
  Bot,
  Share2,
  Maximize,
  Download,
  Paperclip,
  Mic,
  ArrowUp,
  BookOpen,
  Settings,
  UploadCloud,
  FileText,
  Link,
  File,
  Trash2,
  Link2
} from 'lucide-react';

export default function App() {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 overflow-hidden h-screen w-screen relative">
      {/* Background Dashboard (Blurred & Dimmed) */}
      <div className="absolute inset-0 z-0 opacity-40 pointer-events-none filter blur-[4px] select-none overflow-hidden">
        <div className="relative flex h-full w-full flex-col bg-[#102023] overflow-hidden">
          <header className="flex items-center justify-between border-b border-[#224249] px-10 py-3">
            <div className="flex items-center gap-4 text-white">
              <div className="size-8 rounded bg-[#224249]"></div>
              <h2 className="text-lg font-bold">Phase 1: Analysis Dashboard</h2>
            </div>
            <div className="flex gap-4">
              <div className="size-10 rounded-full bg-[#224249]"></div>
            </div>
          </header>
          <div className="flex flex-1 p-8 gap-8">
            <div className="w-64 flex flex-col gap-4">
              <div className="h-12 w-full bg-[#224249] rounded-lg"></div>
              <div className="h-12 w-full bg-[#224249] rounded-lg"></div>
              <div className="h-12 w-full bg-[#224249] rounded-lg"></div>
              <div className="h-12 w-full bg-[#224249] rounded-lg"></div>
            </div>
            <div className="flex-1 flex flex-col gap-6">
              <div className="h-32 w-full bg-[#1A2E33] rounded-xl border border-[#224249]"></div>
              <div className="flex gap-6 h-64">
                <div className="flex-1 bg-[#1A2E33] rounded-xl border border-[#224249]"></div>
                <div className="flex-1 bg-[#1A2E33] rounded-xl border border-[#224249]"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Modal Overlay */}
      <div className="absolute inset-0 z-10 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        {/* Glassmorphism Container */}
        <div className="w-full max-w-[1400px] h-[90vh] bg-glass-dark backdrop-blur-xl border border-glass-border rounded-xl shadow-2xl flex flex-col overflow-hidden ring-1 ring-white/10">
          
          {/* Modal Header */}
          <div className="h-16 border-b border-glass-border flex items-center justify-between px-6 bg-[#102023]/50">
            <div className="flex items-center gap-3">
              <Brain className="text-primary w-8 h-8" />
              <div>
                <h1 className="text-white text-lg font-bold tracking-tight">AI BMAD Domain Research Assistant</h1>
                <p className="text-xs text-slate-400">Project: Fintech Lending Module • Session ID: #8821X</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button className="text-slate-400 hover:text-white transition-colors">
                <Minus className="w-5 h-5" />
              </button>
              <button className="text-slate-400 hover:text-white transition-colors">
                <Maximize2 className="w-5 h-5" />
              </button>
              <button className="text-slate-400 hover:text-primary transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Modal Body */}
          <div className="flex flex-1 overflow-hidden">
            
            {/* Left Column: Stepper Workflow */}
            <div className="w-[280px] border-r border-glass-border bg-[#15262a]/60 flex flex-col p-6 overflow-y-auto">
              <h3 className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-6">Workflow Steps</h3>
              <div className="flex flex-col gap-6 relative">
                {/* Connecting Line */}
                <div className="absolute left-[15px] top-4 bottom-4 w-[2px] bg-[#224249]"></div>
                
                {/* Step 1: Completed */}
                <div className="relative z-10 flex items-start gap-4 group cursor-pointer">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(37,209,244,0.3)]">
                    <Check className="text-[#102023] w-5 h-5 font-bold" />
                  </div>
                  <div className="pt-1">
                    <p className="text-white text-sm font-bold">Industry Taxonomy</p>
                    <p className="text-xs text-primary mt-1">Completed</p>
                  </div>
                </div>

                {/* Step 2: Active */}
                <div className="relative z-10 flex items-start gap-4 group cursor-pointer">
                  <div className="w-8 h-8 rounded-full bg-[#102023] border-2 border-primary flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(37,209,244,0.5)]">
                    <Network className="text-primary w-4 h-4 animate-pulse" />
                  </div>
                  <div className="pt-1">
                    <p className="text-white text-sm font-bold">Stakeholder Mapping</p>
                    <p className="text-xs text-slate-400 mt-1">In Progress...</p>
                  </div>
                </div>

                {/* Step 3: Inactive */}
                <div className="relative z-10 flex items-start gap-4 group cursor-pointer opacity-50 hover:opacity-80 transition-opacity">
                  <div className="w-8 h-8 rounded-full bg-[#1A2E33] border border-slate-600 flex items-center justify-center shrink-0">
                    <span className="text-slate-400 text-sm font-bold">3</span>
                  </div>
                  <div className="pt-1">
                    <p className="text-slate-300 text-sm font-medium">Regulatory & Compliance</p>
                  </div>
                </div>

                {/* Step 4: Inactive */}
                <div className="relative z-10 flex items-start gap-4 group cursor-pointer opacity-50 hover:opacity-80 transition-opacity">
                  <div className="w-8 h-8 rounded-full bg-[#1A2E33] border border-slate-600 flex items-center justify-center shrink-0">
                    <span className="text-slate-400 text-sm font-bold">4</span>
                  </div>
                  <div className="pt-1">
                    <p className="text-slate-300 text-sm font-medium">Core Business Logic</p>
                  </div>
                </div>
              </div>

              <div className="mt-auto pt-8">
                <div className="bg-primary/10 rounded-lg p-4 border border-primary/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="text-primary w-4 h-4" />
                    <span className="text-primary text-xs font-bold uppercase">AI Insight</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Based on your inputs, the system detected high regulatory complexity in the "Underwriter" role.
                  </p>
                </div>
              </div>
            </div>

            {/* Center Column: Chat Interface & Workspace */}
            <div className="flex-1 flex flex-col bg-transparent relative">
              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar flex flex-col gap-6">
                
                {/* AI Message 1 */}
                <div className="flex gap-4 max-w-4xl">
                  <div className="size-10 rounded-full bg-gradient-to-br from-primary to-teal-600 flex items-center justify-center shrink-0 shadow-lg">
                    <Bot className="text-white w-6 h-6" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <div className="bg-[#1A2E33]/80 backdrop-blur-sm border border-white/5 p-4 rounded-2xl rounded-tl-none text-slate-200 text-sm leading-relaxed shadow-sm">
                      <p>I've analyzed the uploaded whitepapers. Based on the <strong>Financial Services Act of 2023</strong> and your internal Confluence pages, I've generated the initial <strong>Stakeholder Map</strong> for the FinTech lending module.</p>
                    </div>
                    <span className="text-[10px] text-slate-500 ml-2">10:42 AM</span>
                  </div>
                </div>

                {/* AI Visualization Card */}
                <div className="pl-14 max-w-4xl w-full">
                  <div className="bg-[#101f22] border border-glass-border rounded-xl p-4 shadow-lg overflow-hidden group">
                    <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-2">
                      <h4 className="text-white text-sm font-bold flex items-center gap-2">
                        <Share2 className="text-primary w-4 h-4" />
                        Stakeholder Map Visualization
                      </h4>
                      <div className="flex gap-2">
                        <button className="text-slate-400 hover:text-white"><Maximize className="w-4 h-4" /></button>
                        <button className="text-slate-400 hover:text-white"><Download className="w-4 h-4" /></button>
                      </div>
                    </div>
                    <div className="relative h-64 w-full bg-[#0d1619] rounded-lg flex items-center justify-center overflow-hidden">
                      <svg className="absolute inset-0 w-full h-full" fill="none" viewBox="0 0 600 300" xmlns="http://www.w3.org/2000/svg">
                        <path d="M300 150 L100 80" stroke="#224249" strokeWidth="2"></path>
                        <path d="M300 150 L500 80" stroke="#224249" strokeWidth="2"></path>
                        <path d="M300 150 L300 250" stroke="#224249" strokeWidth="2"></path>
                        <path d="M100 80 L300 250" stroke="#224249" strokeDasharray="4 4" strokeWidth="1"></path>
                        
                        <circle cx="300" cy="150" fill="#1A2E33" r="30" stroke="#25d1f4" strokeWidth="2"></circle>
                        <text fill="#fff" fontFamily="Space Grotesk" fontSize="10" textAnchor="middle" x="300" y="154">Lending Core</text>
                        
                        <circle cx="100" cy="80" fill="#1A2E33" r="25" stroke="#90c1cb" strokeWidth="1"></circle>
                        <text fill="#ccc" fontFamily="Space Grotesk" fontSize="9" textAnchor="middle" x="100" y="84">Borrower</text>
                        
                        <circle cx="500" cy="80" fill="#1A2E33" r="25" stroke="#90c1cb" strokeWidth="1"></circle>
                        <text fill="#ccc" fontFamily="Space Grotesk" fontSize="9" textAnchor="middle" x="500" y="84">Bank Partner</text>
                        
                        <circle cx="300" cy="250" fill="#224249" r="25" stroke="#90c1cb" strokeWidth="1"></circle>
                        <text fill="#fff" fontFamily="Space Grotesk" fontSize="9" textAnchor="middle" x="300" y="254">Compliance</text>
                        
                        <circle cx="300" cy="150" r="30" stroke="#25d1f4" strokeOpacity="0.5" strokeWidth="1">
                          <animate attributeName="r" dur="2s" from="30" repeatCount="indefinite" to="45"></animate>
                          <animate attributeName="opacity" dur="2s" from="1" repeatCount="indefinite" to="0"></animate>
                        </circle>
                      </svg>
                    </div>
                  </div>
                </div>

                {/* User Message */}
                <div className="flex flex-row-reverse gap-4 max-w-4xl self-end">
                  <div className="size-10 rounded-full bg-[#224249] flex items-center justify-center shrink-0 border border-white/10 overflow-hidden">
                    <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuCDkl2UK8ihOvyUYcxzSO_PdFM4w1a4no2JzvuNVBo2kGxWAqFwmVaqfInjAiG4RGxq1TYt22x17O1WszhKsQ2dT0ftXYOtbwsevBjNri5Ox-wctZC6kU0ObW-Mlc6fZJ8lt1BCAUb7YaJ5WCl0sSj5dhQHU1QrcRdvLw-Hy-bT6umRWTx9gTvIkN-H2VTdYcVzBsWD9cux--F3nLg44aOwkUIlt7UO69gyEIpDUZENnVDCl4WiBObzG8zFNR6nMsT05tme435yLvST" alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex flex-col gap-2 items-end">
                    <div className="bg-primary/20 border border-primary/30 p-4 rounded-2xl rounded-tr-none text-slate-100 text-sm leading-relaxed shadow-sm">
                      <p>This looks good. Are there any specific terms I should be aware of regarding the "Compliance" node?</p>
                    </div>
                    <span className="text-[10px] text-slate-500 mr-2">10:44 AM</span>
                  </div>
                </div>

                {/* AI Message 2 */}
                <div className="flex gap-4 max-w-4xl">
                  <div className="size-10 rounded-full bg-gradient-to-br from-primary to-teal-600 flex items-center justify-center shrink-0 shadow-lg">
                    <Bot className="text-white w-6 h-6" />
                  </div>
                  <div className="flex flex-col gap-2 w-full">
                    <div className="bg-[#1A2E33]/80 backdrop-blur-sm border border-white/5 p-4 rounded-2xl rounded-tl-none text-slate-200 text-sm leading-relaxed shadow-sm">
                      <p>Yes, based on the context, here are key terms for the <strong>Domain Glossary</strong> related to compliance:</p>
                    </div>
                    
                    {/* Glossary Card */}
                    <div className="bg-[#101f22] border border-glass-border rounded-xl overflow-hidden mt-1 w-full max-w-2xl shadow-lg">
                      <div className="bg-[#15262a] px-4 py-2 border-b border-white/5 flex justify-between items-center">
                        <span className="text-xs font-bold text-primary uppercase tracking-wider">Generated Glossary</span>
                        <span className="text-[10px] text-slate-400">3 Terms Identified</span>
                      </div>
                      <div className="divide-y divide-white/5">
                        <div className="p-4 hover:bg-white/5 transition-colors cursor-pointer group">
                          <div className="flex justify-between items-start">
                            <h5 className="text-white font-bold text-sm mb-1 group-hover:text-primary transition-colors">KYC (Know Your Customer)</h5>
                            <span className="bg-[#224249] text-xs px-2 py-0.5 rounded text-slate-300">Regulatory</span>
                          </div>
                          <p className="text-xs text-slate-400 leading-normal">Mandatory framework for verifying the identity of clients to assess their suitability and risks.</p>
                        </div>
                        <div className="p-4 hover:bg-white/5 transition-colors cursor-pointer group">
                          <div className="flex justify-between items-start">
                            <h5 className="text-white font-bold text-sm mb-1 group-hover:text-primary transition-colors">AML (Anti-Money Laundering)</h5>
                            <span className="bg-[#224249] text-xs px-2 py-0.5 rounded text-slate-300">Compliance</span>
                          </div>
                          <p className="text-xs text-slate-400 leading-normal">Laws, regulations, and procedures intended to prevent criminals from disguising illegally obtained funds as legitimate income.</p>
                        </div>
                        <div className="p-4 hover:bg-white/5 transition-colors cursor-pointer group">
                          <div className="flex justify-between items-start">
                            <h5 className="text-white font-bold text-sm mb-1 group-hover:text-primary transition-colors">UBO (Ultimate Beneficial Owner)</h5>
                            <span className="bg-[#224249] text-xs px-2 py-0.5 rounded text-slate-300">Entity</span>
                          </div>
                          <p className="text-xs text-slate-400 leading-normal">The person or entity that is the ultimate beneficiary when an institution initiates a transaction.</p>
                        </div>
                      </div>
                      <div className="px-4 py-2 bg-[#15262a] text-center border-t border-white/5">
                        <button className="text-xs text-primary font-bold hover:underline">Add All to Domain Model</button>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-500 ml-2">10:45 AM</span>
                  </div>
                </div>
              </div>

              {/* Input Area */}
              <div className="p-6 pt-0">
                <div className="relative flex items-end gap-2 bg-[#101f22] border border-glass-border rounded-xl p-2 shadow-2xl ring-1 ring-white/5">
                  <button className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors" title="Attach Files">
                    <Paperclip className="w-5 h-5" />
                  </button>
                  <textarea 
                    className="w-full bg-transparent border-none text-slate-200 text-sm focus:ring-0 p-2 max-h-32 min-h-[44px] resize-none placeholder-slate-500 outline-none" 
                    placeholder="Ask AI to refine definitions or add new stakeholders..." 
                    rows={1}
                  ></textarea>
                  <div className="flex items-center gap-1 pb-1">
                    <button className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors" title="Voice Input">
                      <Mic className="w-5 h-5" />
                    </button>
                    <button className="h-9 w-9 bg-primary hover:bg-primary/90 text-[#102023] rounded-lg flex items-center justify-center transition-all shadow-[0_0_10px_rgba(37,209,244,0.3)]">
                      <ArrowUp className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div className="flex justify-center mt-2">
                  <p className="text-[10px] text-slate-500">AI can make mistakes. Please verify important information.</p>
                </div>
              </div>
            </div>

            {/* Right Column: Knowledge Base Sidebar */}
            <div className="w-[300px] border-l border-glass-border bg-[#15262a]/60 flex flex-col overflow-hidden">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <h3 className="text-slate-200 text-sm font-bold flex items-center gap-2">
                  <BookOpen className="text-primary w-4 h-4" />
                  Knowledge Base
                </h3>
                <button className="text-slate-500 hover:text-white">
                  <Settings className="w-4 h-4" />
                </button>
              </div>
              <div className="p-4 flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-6">
                
                {/* Upload Zone */}
                <div className="border-2 border-dashed border-slate-600 rounded-xl p-6 flex flex-col items-center justify-center text-center hover:border-primary/50 hover:bg-primary/5 transition-all cursor-pointer group">
                  <UploadCloud className="text-slate-500 group-hover:text-primary w-8 h-8 mb-2" />
                  <p className="text-xs text-slate-300 font-medium">Drop whitepapers here</p>
                  <p className="text-[10px] text-slate-500 mt-1">PDF, DOCX, TXT supported</p>
                </div>

                {/* Context Sources List */}
                <div className="flex flex-col gap-3">
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Active Context</p>
                  
                  {/* Source Item 1 */}
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-[#101f22] border border-white/5 hover:border-primary/30 transition-colors group">
                    <div className="mt-0.5 text-red-400">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-200 text-xs font-bold truncate group-hover:text-primary">Q3_Compliance_Memo.pdf</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Uploaded 2h ago • 2.4MB</p>
                    </div>
                    <button className="text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Source Item 2 */}
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-[#101f22] border border-white/5 hover:border-primary/30 transition-colors group">
                    <div className="mt-0.5 text-blue-400">
                      <Link className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-200 text-xs font-bold truncate group-hover:text-primary">Confluence: /Lending_Logic</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Synced just now</p>
                    </div>
                    <button className="text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Source Item 3 */}
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-[#101f22] border border-white/5 hover:border-primary/30 transition-colors group opacity-60">
                    <div className="mt-0.5 text-slate-400">
                      <File className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-200 text-xs font-bold truncate group-hover:text-primary">Legacy_System_Specs.docx</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Processing...</p>
                    </div>
                    <div className="animate-spin h-3 w-3 border-2 border-primary border-t-transparent rounded-full mt-1"></div>
                  </div>
                </div>
              </div>
              <div className="p-4 border-t border-white/5 bg-[#101f22]/50">
                <button className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-[#224249] hover:bg-[#2c555e] text-xs font-bold text-white transition-colors">
                  <Link2 className="w-4 h-4" />
                  Connect New Source
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
